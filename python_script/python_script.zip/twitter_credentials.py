# Variables that contains the user credentials to access Twitter API 
ACCESS_TOKEN = "119144517-nsO8LiA8ikjEsdEYA0dS0uOmu3ZO9bTJaKH5DxMR"
ACCESS_TOKEN_SECRET = "rEUEQQmMOoGTcTkeqqPfwB6ZREiTubpuVaiVQubmV58aY"
CONSUMER_KEY = "eSzJJOiIMQZB8ydjmxtKwDfyx"
CONSUMER_SECRET = "nhSXKVYEyqaMnpp1OuaNr3c2vwqJG8hevV2gGe59l4mRN0s2eT"
